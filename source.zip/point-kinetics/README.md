# Point reactor kinetics

Educational seven-state model. No thermal feedback, spatial distribution or decay heat.

Use Python 3.14, create a virtual environment, then run:

```sh
python -m pip install -r requirements.txt
python kinetics.py
```

The script runs numerical checks and writes five figures beside itself. See the accompanying technical report for parameters, sources, full verification scope and additional table reproduction. AI-assisted educational project.
