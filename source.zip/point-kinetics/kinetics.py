"""Lesson 1: equilibrium and constant-reactivity steps; run directly to check/plot."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import expm

# Ragheb, Point Reactor Kinetics (2014), Table 1, PDF page 10.
# Thermal U-235 yield fractions used as illustrative effective fractions.
BETA_I = np.array([0.000215, 0.001424, 0.001274, 0.002568, 0.000748, 0.000273])
DECAY = np.array([0.0124, 0.0305, 0.111, 0.301, 1.14, 3.01])  # 1/s
BETA = BETA_I.sum()  # 0.006502: retain the sum of the rounded entries.
GENERATION_TIME = 1e-4  # s; illustrative assumption, not plant-specific data.
INITIAL = np.r_[1.0, BETA_I / (GENERATION_TIME * DECAY)]


def derivative(t, state, rho, generation_time=GENERATION_TIME):
    """state = [n/n0, C1/n0, ..., C6/n0]; rho is dimensionless."""
    n, precursors = state[0], state[1:]
    dn = (rho - BETA) / generation_time * n + DECAY @ precursors
    dc = BETA_I / generation_time * n - DECAY * precursors
    return np.r_[dn, dc]


def simulate(rho, times, rtol=1e-8, ramp_seconds=0, generation_time=GENERATION_TIME):
    """Step to rho, or ramp from zero to rho over ramp_seconds, then hold."""
    times = np.asarray(times, dtype=float)
    if not np.isfinite(rho) or not (times.ndim == 1 and len(times) >= 2
            and np.all(np.isfinite(times)) and times[0] == 0
            and np.all(np.diff(times) > 0)):
        raise ValueError("Need finite rho and increasing finite times starting at zero.")
    if not np.isfinite(ramp_seconds) or ramp_seconds < 0:
        raise ValueError("Ramp duration must be finite and nonnegative.")
    if not np.isfinite(generation_time) or generation_time <= 0:
        raise ValueError("Generation time must be finite and positive.")
    def rhs(t, state):
        applied = rho * min(t / ramp_seconds, 1.0) if ramp_seconds else rho
        return derivative(t, state, applied, generation_time)
    # Restart at the ramp endpoint so the solver handles the change in slope.
    boundaries = [0, times[-1]]
    if 0 < ramp_seconds < times[-1]:
        boundaries.insert(1, ramp_seconds)
    state = np.r_[1.0, BETA_I / (generation_time * DECAY)]
    values = np.empty((7, len(times)))
    for start, end in zip(boundaries[:-1], boundaries[1:]):
        result = solve_ivp(rhs, (start, end), state, method="Radau",
                           dense_output=True, rtol=rtol, atol=rtol * 0.01)
        if not result.success or not np.all(np.isfinite(result.y)):
            raise RuntimeError(result.message)
        selected = (times >= start) & (times <= end)
        values[:, selected] = result.sol(times[selected])
        state = result.y[:, -1]
    return values


def self_check():
    """Physical equilibrium plus an independent constant-matrix solution."""
    times = np.array([0, 0.01, 0.1, 1, 10, 60.0])
    np.testing.assert_allclose(derivative(0, INITIAL, 0), 0, atol=1e-12)
    np.testing.assert_allclose(simulate(0, times),
                               np.repeat(INITIAL[:, None], len(times), axis=1),
                               rtol=1e-9, atol=1e-10)
    for rho in (0.1 * BETA, -0.1 * BETA):
        matrix = np.zeros((7, 7))
        matrix[0, 0] = (rho - BETA) / GENERATION_TIME
        matrix[0, 1:] = DECAY
        matrix[1:, 0] = BETA_I / GENERATION_TIME
        matrix[1:, 1:] = -np.diag(DECAY)
        reference = np.column_stack([expm(matrix * t) @ INITIAL for t in times])
        numerical = simulate(rho, times)
        np.testing.assert_allclose(numerical, reference, rtol=2e-7, atol=1e-9)
        np.testing.assert_allclose(numerical, simulate(rho, times, rtol=1e-10),
                                   rtol=2e-7, atol=1e-9)
    print("PASS: equilibrium, positive/negative step matrix benchmark, tolerance refinement")
    ramp = simulate(0.1 * BETA, times, ramp_seconds=10)
    np.testing.assert_allclose(ramp,
        simulate(0.1 * BETA, times, rtol=1e-10, ramp_seconds=10), rtol=2e-7)
    assert 1 < ramp[0, -2] < simulate(0.1 * BETA, times)[0, -2]
    # Independently continue the ramp endpoint with constant-reactivity expm.
    matrix[0, 0] = (0.1 * BETA - BETA) / GENERATION_TIME
    np.testing.assert_allclose(ramp[:, -1], expm(matrix * 50) @ ramp[:, -2], rtol=2e-7)
    print("PASS: ramp convergence, ordering at 10 s, post-ramp matrix benchmark")
    generation_time = 1e-5
    initial = np.r_[1., BETA_I / (generation_time * DECAY)]
    equilibrium = simulate(0, times, generation_time=generation_time)
    np.testing.assert_allclose(equilibrium, np.repeat(initial[:, None], len(times), axis=1), rtol=1e-9)
    matrix[0, 0] = (0.1 * BETA - BETA) / generation_time
    matrix[1:, 0] = BETA_I / generation_time
    reference = np.column_stack([expm(matrix * t) @ initial for t in times])
    np.testing.assert_allclose(simulate(0.1 * BETA, times, generation_time=generation_time), reference, rtol=2e-7)
    print("PASS: shorter generation-time equilibrium and matrix benchmark")


if __name__ == "__main__":
    self_check()
    times = np.unique(np.r_[0, np.geomspace(1e-5, 60, 1200)])
    fig, axes = plt.subplots(1, 2, figsize=(11, 4), layout="constrained")
    for dollars, label, color in [(0, "Equilibrium", "#555555"),
                                  (0.1, "+0.10 dollars", "#bd491f"),
                                  (-0.1, "−0.10 dollars", "#177e89")]:
        power = simulate(dollars * BETA, times)[0]
        for ax in axes:
            ax.plot(times, power, label=label, color=color, linewidth=2)
        print(f"{label}: P(60 s)/P0 = {power[-1]:.6f}")
    axes[0].set(xlim=(0, 1), title="First second: fast adjustment")
    axes[1].set(xlim=(0, 60), title="Full minute: continued evolution")
    for ax in axes:
        ax.set(xlabel="Time after step (s)", ylabel="Normalized fission power P/P₀")
        ax.grid(alpha=0.2)
        ax.legend()
    fig.suptitle("Six-group point kinetics • fixed parameters • no temperature feedback")
    fig.savefig(Path(__file__).with_name("first_results.png"), dpi=170)
    plt.close(fig)
    times = np.unique(np.r_[0, np.geomspace(1e-5, 60, 1200), 10, 30])
    fig, axes = plt.subplots(2, 1, figsize=(9, 7), sharex=True, layout="constrained")
    for duration, label, color in [(0, "Immediate step", "#bd491f"),
                                    (10, "10-second ramp", "#177e89")]:
        power = simulate(0.1 * BETA, times, ramp_seconds=duration)[0]
        applied = 0.1 * np.minimum(times / duration, 1) if duration else np.full_like(times, 0.1)
        axes[0].plot(times, applied, label=label, color=color, linewidth=2)
        axes[1].plot(times, power, label=label, color=color, linewidth=2)
        for t in (10, 30, 60):
            print(f"{label}: P({t} s)/P0 = {power[times == t][0]:.6f}")
    axes[0].set(ylabel="Reactivity (dollars)", ylim=(0, 0.12), title="Input: same target, different timing")
    axes[1].set(ylabel="Normalized fission power P/P₀", xlabel="Time (s)", title="Response: the earlier increase has a lasting effect")
    for ax in axes:
        ax.axvline(10, color="gray", linestyle=":", linewidth=1)
        ax.set_xlim(0, 60)
        ax.grid(alpha=0.2)
        ax.legend()
    fig.suptitle("Step versus ramp • no temperature feedback")
    fig.savefig(Path(__file__).with_name("step_vs_ramp.png"), dpi=170)
    plt.close(fig)
    for dollars, filename in [(0.1, "precursor_response.png"),
                              (-0.1, "negative_precursor_response.png")]:
        states = simulate(dollars * BETA, times)
        relative_precursors = states[1:] / INITIAL[1:, None]
        np.testing.assert_allclose(relative_precursors[:, 0], 1)
        fig, ax = plt.subplots(figsize=(10, 6), layout="constrained")
        colors = ["#4477aa", "#66ccee", "#228833", "#ccbb44", "#ee6677", "#aa3377"]
        for i, (decay, color) in enumerate(zip(DECAY, colors)):
            ax.plot(times, relative_precursors[i], color=color, linewidth=2,
                    label=f"Group {i+1}: τ = {1/decay:.2f} s")
            print(f"{dollars:+.2f} dollars, group {i+1}: C(60 s)/C(0) = {relative_precursors[i, -1]:.6f}")
        ax.plot(times, states[0], color="black", linestyle="--", linewidth=2,
                label="Fission power P/P₀")
        ax.set(xlim=(0, 60), xlabel="Time after step (s)",
               ylabel="Multiple of each quantity’s own starting value",
               title=f"Precursor response to {dollars:+.2f} dollars\nFast groups follow changing power more closely")
        ax.grid(alpha=0.2)
        ax.legend()
        fig.savefig(Path(__file__).with_name(filename), dpi=170)
        plt.close(fig)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5), layout="constrained")
    for generation_time, color in [(1e-4, "#bd491f"), (1e-5, "#177e89")]:
        power = simulate(0.1 * BETA, times, generation_time=generation_time)[0]
        for ax in axes:
            ax.plot(times, power, color=color, linewidth=2,
                    label=f"Generation time = {generation_time * 1e6:.0f} microseconds")
        sample = simulate(0.1 * BETA, [0, .01, .1, 60], generation_time=generation_time)[0]
        print(f"Generation time {generation_time:g} s: power at 0.01, 0.1, 60 s = {sample[1:]}")
    axes[0].axhline(1 / .9, color="gray", linestyle=":", label="Prompt-jump estimate: 1.111")
    axes[0].set(xlim=(0, .1), ylim=(.995, 1.125), title="First tenth of a second (zoomed)")
    axes[1].set(xlim=(0, 60), title="Full minute: curves nearly overlap")
    for ax in axes:
        ax.set(xlabel="Time after step (s)", ylabel="Normalized fission power P/P₀")
        ax.legend(fontsize=8)
        ax.grid(alpha=.2)
    fig.suptitle("Same +0.10-dollar step • different prompt generation times")
    fig.savefig(Path(__file__).with_name("generation_time_comparison.png"), dpi=170)
    plt.close(fig)
